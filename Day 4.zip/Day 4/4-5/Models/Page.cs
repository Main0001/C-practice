﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _4_5.Models
{
    internal class Page
    {
        public string[] Words { get; set; } = default;
        public int Number { get; set; }
    }
}
