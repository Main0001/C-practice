﻿using ScheduleLib;

Schedule schedal = new Schedule(DateTime.Now, DateTime.Now, "Test", "test schedal");

Console.WriteLine(schedal.Info());