﻿using _30_1.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Linq;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _30_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
          DataContext db = new DataContext(@"Initial Catalog = DBTur_firm.mdf; Integrated Security = True");
            var cust = (from c in db.GetTable<Turist>()
                           where c.Name == "1"
                           orderby c.Id
                           select c);
            foreach (var c in cust)
                MessageBox.Show($"{c.Id}");
        }
    }
}
