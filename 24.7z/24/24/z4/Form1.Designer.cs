﻿
namespace z4
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label12 = new System.Windows.Forms.Label();
            this.radioButton9 = new System.Windows.Forms.RadioButton();
            this.radioButton10 = new System.Windows.Forms.RadioButton();
            this.radioButton11 = new System.Windows.Forms.RadioButton();
            this.HR_Resume = new System.Windows.Forms.TextBox();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton12 = new System.Windows.Forms.RadioButton();
            this.YearDropBox = new System.Windows.Forms.ComboBox();
            this.Month = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.Day = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.button2 = new System.Windows.Forms.Button();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.SalaryTo = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.SalaryFrom = new System.Windows.Forms.NumericUpDown();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.radioButton8 = new System.Windows.Forms.RadioButton();
            this.radioButton7 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.radioButton6 = new System.Windows.Forms.RadioButton();
            this.button3 = new System.Windows.Forms.Button();
            this.Name = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Patronymic = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Sourname = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.Place = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.Phone = new System.Windows.Forms.TextBox();
            this.Mobile = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.Email = new System.Windows.Forms.TextBox();
            this.helpProvider1 = new System.Windows.Forms.HelpProvider();
            this.button7 = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox4.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SalaryTo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SalaryFrom)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label12
            // 
            resources.ApplyResources(this.label12, "label12");
            this.label12.ForeColor = System.Drawing.SystemColors.Desktop;
            this.helpProvider1.SetHelpKeyword(this.label12, resources.GetString("label12.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.label12, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("label12.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.label12, resources.GetString("label12.HelpString"));
            this.label12.Name = "label12";
            this.helpProvider1.SetShowHelp(this.label12, ((bool)(resources.GetObject("label12.ShowHelp"))));
            this.toolTip1.SetToolTip(this.label12, resources.GetString("label12.ToolTip"));
            // 
            // radioButton9
            // 
            resources.ApplyResources(this.radioButton9, "radioButton9");
            this.radioButton9.ForeColor = System.Drawing.SystemColors.Desktop;
            this.helpProvider1.SetHelpKeyword(this.radioButton9, resources.GetString("radioButton9.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.radioButton9, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("radioButton9.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.radioButton9, resources.GetString("radioButton9.HelpString"));
            this.radioButton9.Name = "radioButton9";
            this.helpProvider1.SetShowHelp(this.radioButton9, ((bool)(resources.GetObject("radioButton9.ShowHelp"))));
            this.radioButton9.TabStop = true;
            this.toolTip1.SetToolTip(this.radioButton9, resources.GetString("radioButton9.ToolTip"));
            this.radioButton9.UseVisualStyleBackColor = true;
            // 
            // radioButton10
            // 
            resources.ApplyResources(this.radioButton10, "radioButton10");
            this.radioButton10.ForeColor = System.Drawing.SystemColors.Desktop;
            this.helpProvider1.SetHelpKeyword(this.radioButton10, resources.GetString("radioButton10.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.radioButton10, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("radioButton10.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.radioButton10, resources.GetString("radioButton10.HelpString"));
            this.radioButton10.Name = "radioButton10";
            this.helpProvider1.SetShowHelp(this.radioButton10, ((bool)(resources.GetObject("radioButton10.ShowHelp"))));
            this.radioButton10.TabStop = true;
            this.toolTip1.SetToolTip(this.radioButton10, resources.GetString("radioButton10.ToolTip"));
            this.radioButton10.UseVisualStyleBackColor = true;
            // 
            // radioButton11
            // 
            resources.ApplyResources(this.radioButton11, "radioButton11");
            this.radioButton11.ForeColor = System.Drawing.SystemColors.Desktop;
            this.helpProvider1.SetHelpKeyword(this.radioButton11, resources.GetString("radioButton11.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.radioButton11, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("radioButton11.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.radioButton11, resources.GetString("radioButton11.HelpString"));
            this.radioButton11.Name = "radioButton11";
            this.helpProvider1.SetShowHelp(this.radioButton11, ((bool)(resources.GetObject("radioButton11.ShowHelp"))));
            this.radioButton11.TabStop = true;
            this.toolTip1.SetToolTip(this.radioButton11, resources.GetString("radioButton11.ToolTip"));
            this.radioButton11.UseVisualStyleBackColor = true;
            // 
            // HR_Resume
            // 
            resources.ApplyResources(this.HR_Resume, "HR_Resume");
            this.helpProvider1.SetHelpKeyword(this.HR_Resume, resources.GetString("HR_Resume.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.HR_Resume, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("HR_Resume.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.HR_Resume, resources.GetString("HR_Resume.HelpString"));
            this.HR_Resume.Name = "HR_Resume";
            this.helpProvider1.SetShowHelp(this.HR_Resume, ((bool)(resources.GetObject("HR_Resume.ShowHelp"))));
            this.toolTip1.SetToolTip(this.HR_Resume, resources.GetString("HR_Resume.ToolTip"));
            // 
            // radioButton3
            // 
            resources.ApplyResources(this.radioButton3, "radioButton3");
            this.radioButton3.ForeColor = System.Drawing.SystemColors.Desktop;
            this.helpProvider1.SetHelpKeyword(this.radioButton3, resources.GetString("radioButton3.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.radioButton3, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("radioButton3.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.radioButton3, resources.GetString("radioButton3.HelpString"));
            this.radioButton3.Name = "radioButton3";
            this.helpProvider1.SetShowHelp(this.radioButton3, ((bool)(resources.GetObject("radioButton3.ShowHelp"))));
            this.radioButton3.TabStop = true;
            this.toolTip1.SetToolTip(this.radioButton3, resources.GetString("radioButton3.ToolTip"));
            this.radioButton3.UseVisualStyleBackColor = true;
            this.radioButton3.CheckedChanged += new System.EventHandler(this.radioButton3_CheckedChanged);
            // 
            // radioButton2
            // 
            resources.ApplyResources(this.radioButton2, "radioButton2");
            this.radioButton2.ForeColor = System.Drawing.SystemColors.Desktop;
            this.helpProvider1.SetHelpKeyword(this.radioButton2, resources.GetString("radioButton2.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.radioButton2, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("radioButton2.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.radioButton2, resources.GetString("radioButton2.HelpString"));
            this.radioButton2.Name = "radioButton2";
            this.helpProvider1.SetShowHelp(this.radioButton2, ((bool)(resources.GetObject("radioButton2.ShowHelp"))));
            this.radioButton2.TabStop = true;
            this.toolTip1.SetToolTip(this.radioButton2, resources.GetString("radioButton2.ToolTip"));
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            resources.ApplyResources(this.radioButton1, "radioButton1");
            this.radioButton1.ForeColor = System.Drawing.SystemColors.Desktop;
            this.helpProvider1.SetHelpKeyword(this.radioButton1, resources.GetString("radioButton1.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.radioButton1, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("radioButton1.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.radioButton1, resources.GetString("radioButton1.HelpString"));
            this.radioButton1.Name = "radioButton1";
            this.helpProvider1.SetShowHelp(this.radioButton1, ((bool)(resources.GetObject("radioButton1.ShowHelp"))));
            this.radioButton1.TabStop = true;
            this.toolTip1.SetToolTip(this.radioButton1, resources.GetString("radioButton1.ToolTip"));
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton12
            // 
            resources.ApplyResources(this.radioButton12, "radioButton12");
            this.radioButton12.ForeColor = System.Drawing.SystemColors.Desktop;
            this.helpProvider1.SetHelpKeyword(this.radioButton12, resources.GetString("radioButton12.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.radioButton12, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("radioButton12.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.radioButton12, resources.GetString("radioButton12.HelpString"));
            this.radioButton12.Name = "radioButton12";
            this.helpProvider1.SetShowHelp(this.radioButton12, ((bool)(resources.GetObject("radioButton12.ShowHelp"))));
            this.radioButton12.TabStop = true;
            this.toolTip1.SetToolTip(this.radioButton12, resources.GetString("radioButton12.ToolTip"));
            this.radioButton12.UseVisualStyleBackColor = true;
            // 
            // YearDropBox
            // 
            resources.ApplyResources(this.YearDropBox, "YearDropBox");
            this.YearDropBox.FormattingEnabled = true;
            this.helpProvider1.SetHelpKeyword(this.YearDropBox, resources.GetString("YearDropBox.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.YearDropBox, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("YearDropBox.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.YearDropBox, resources.GetString("YearDropBox.HelpString"));
            this.YearDropBox.Items.AddRange(new object[] {
            resources.GetString("YearDropBox.Items"),
            resources.GetString("YearDropBox.Items1"),
            resources.GetString("YearDropBox.Items2"),
            resources.GetString("YearDropBox.Items3"),
            resources.GetString("YearDropBox.Items4"),
            resources.GetString("YearDropBox.Items5"),
            resources.GetString("YearDropBox.Items6"),
            resources.GetString("YearDropBox.Items7"),
            resources.GetString("YearDropBox.Items8"),
            resources.GetString("YearDropBox.Items9"),
            resources.GetString("YearDropBox.Items10"),
            resources.GetString("YearDropBox.Items11"),
            resources.GetString("YearDropBox.Items12"),
            resources.GetString("YearDropBox.Items13"),
            resources.GetString("YearDropBox.Items14"),
            resources.GetString("YearDropBox.Items15"),
            resources.GetString("YearDropBox.Items16"),
            resources.GetString("YearDropBox.Items17"),
            resources.GetString("YearDropBox.Items18"),
            resources.GetString("YearDropBox.Items19"),
            resources.GetString("YearDropBox.Items20"),
            resources.GetString("YearDropBox.Items21"),
            resources.GetString("YearDropBox.Items22"),
            resources.GetString("YearDropBox.Items23"),
            resources.GetString("YearDropBox.Items24"),
            resources.GetString("YearDropBox.Items25"),
            resources.GetString("YearDropBox.Items26"),
            resources.GetString("YearDropBox.Items27"),
            resources.GetString("YearDropBox.Items28"),
            resources.GetString("YearDropBox.Items29"),
            resources.GetString("YearDropBox.Items30")});
            this.YearDropBox.Name = "YearDropBox";
            this.helpProvider1.SetShowHelp(this.YearDropBox, ((bool)(resources.GetObject("YearDropBox.ShowHelp"))));
            this.toolTip1.SetToolTip(this.YearDropBox, resources.GetString("YearDropBox.ToolTip"));
            // 
            // Month
            // 
            resources.ApplyResources(this.Month, "Month");
            this.Month.FormattingEnabled = true;
            this.helpProvider1.SetHelpKeyword(this.Month, resources.GetString("Month.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.Month, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("Month.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.Month, resources.GetString("Month.HelpString"));
            this.Month.Items.AddRange(new object[] {
            resources.GetString("Month.Items"),
            resources.GetString("Month.Items1"),
            resources.GetString("Month.Items2"),
            resources.GetString("Month.Items3"),
            resources.GetString("Month.Items4"),
            resources.GetString("Month.Items5"),
            resources.GetString("Month.Items6"),
            resources.GetString("Month.Items7"),
            resources.GetString("Month.Items8"),
            resources.GetString("Month.Items9"),
            resources.GetString("Month.Items10"),
            resources.GetString("Month.Items11")});
            this.Month.Name = "Month";
            this.helpProvider1.SetShowHelp(this.Month, ((bool)(resources.GetObject("Month.ShowHelp"))));
            this.toolTip1.SetToolTip(this.Month, resources.GetString("Month.ToolTip"));
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.ForeColor = System.Drawing.SystemColors.Desktop;
            this.helpProvider1.SetHelpKeyword(this.label5, resources.GetString("label5.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.label5, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("label5.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.label5, resources.GetString("label5.HelpString"));
            this.label5.Name = "label5";
            this.helpProvider1.SetShowHelp(this.label5, ((bool)(resources.GetObject("label5.ShowHelp"))));
            this.toolTip1.SetToolTip(this.label5, resources.GetString("label5.ToolTip"));
            // 
            // Day
            // 
            resources.ApplyResources(this.Day, "Day");
            this.Day.FormattingEnabled = true;
            this.helpProvider1.SetHelpKeyword(this.Day, resources.GetString("Day.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.Day, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("Day.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.Day, resources.GetString("Day.HelpString"));
            this.Day.Items.AddRange(new object[] {
            resources.GetString("Day.Items"),
            resources.GetString("Day.Items1"),
            resources.GetString("Day.Items2"),
            resources.GetString("Day.Items3"),
            resources.GetString("Day.Items4"),
            resources.GetString("Day.Items5"),
            resources.GetString("Day.Items6"),
            resources.GetString("Day.Items7"),
            resources.GetString("Day.Items8"),
            resources.GetString("Day.Items9"),
            resources.GetString("Day.Items10"),
            resources.GetString("Day.Items11"),
            resources.GetString("Day.Items12"),
            resources.GetString("Day.Items13"),
            resources.GetString("Day.Items14"),
            resources.GetString("Day.Items15"),
            resources.GetString("Day.Items16"),
            resources.GetString("Day.Items17"),
            resources.GetString("Day.Items18"),
            resources.GetString("Day.Items19"),
            resources.GetString("Day.Items20"),
            resources.GetString("Day.Items21"),
            resources.GetString("Day.Items22"),
            resources.GetString("Day.Items23"),
            resources.GetString("Day.Items24"),
            resources.GetString("Day.Items25"),
            resources.GetString("Day.Items26"),
            resources.GetString("Day.Items27"),
            resources.GetString("Day.Items28"),
            resources.GetString("Day.Items29"),
            resources.GetString("Day.Items30")});
            this.Day.Name = "Day";
            this.helpProvider1.SetShowHelp(this.Day, ((bool)(resources.GetObject("Day.ShowHelp"))));
            this.toolTip1.SetToolTip(this.Day, resources.GetString("Day.ToolTip"));
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.ForeColor = System.Drawing.SystemColors.Desktop;
            this.helpProvider1.SetHelpKeyword(this.label4, resources.GetString("label4.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.label4, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("label4.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.label4, resources.GetString("label4.HelpString"));
            this.label4.Name = "label4";
            this.helpProvider1.SetShowHelp(this.label4, ((bool)(resources.GetObject("label4.ShowHelp"))));
            this.toolTip1.SetToolTip(this.label4, resources.GetString("label4.ToolTip"));
            // 
            // button4
            // 
            resources.ApplyResources(this.button4, "button4");
            this.helpProvider1.SetHelpKeyword(this.button4, resources.GetString("button4.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.button4, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("button4.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.button4, resources.GetString("button4.HelpString"));
            this.button4.Name = "button4";
            this.helpProvider1.SetShowHelp(this.button4, ((bool)(resources.GetObject("button4.ShowHelp"))));
            this.toolTip1.SetToolTip(this.button4, resources.GetString("button4.ToolTip"));
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            resources.ApplyResources(this.button5, "button5");
            this.helpProvider1.SetHelpKeyword(this.button5, resources.GetString("button5.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.button5, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("button5.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.button5, resources.GetString("button5.HelpString"));
            this.button5.Name = "button5";
            this.helpProvider1.SetShowHelp(this.button5, ((bool)(resources.GetObject("button5.ShowHelp"))));
            this.toolTip1.SetToolTip(this.button5, resources.GetString("button5.ToolTip"));
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            resources.ApplyResources(this.button6, "button6");
            this.helpProvider1.SetHelpKeyword(this.button6, resources.GetString("button6.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.button6, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("button6.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.button6, resources.GetString("button6.HelpString"));
            this.button6.Name = "button6";
            this.helpProvider1.SetShowHelp(this.button6, ((bool)(resources.GetObject("button6.ShowHelp"))));
            this.toolTip1.SetToolTip(this.button6, resources.GetString("button6.ToolTip"));
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // label6
            // 
            resources.ApplyResources(this.label6, "label6");
            this.label6.ForeColor = System.Drawing.SystemColors.Desktop;
            this.helpProvider1.SetHelpKeyword(this.label6, resources.GetString("label6.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.label6, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("label6.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.label6, resources.GetString("label6.HelpString"));
            this.label6.Name = "label6";
            this.helpProvider1.SetShowHelp(this.label6, ((bool)(resources.GetObject("label6.ShowHelp"))));
            this.toolTip1.SetToolTip(this.label6, resources.GetString("label6.ToolTip"));
            // 
            // label13
            // 
            resources.ApplyResources(this.label13, "label13");
            this.label13.ForeColor = System.Drawing.SystemColors.Desktop;
            this.helpProvider1.SetHelpKeyword(this.label13, resources.GetString("label13.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.label13, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("label13.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.label13, resources.GetString("label13.HelpString"));
            this.label13.Name = "label13";
            this.helpProvider1.SetShowHelp(this.label13, ((bool)(resources.GetObject("label13.ShowHelp"))));
            this.toolTip1.SetToolTip(this.label13, resources.GetString("label13.ToolTip"));
            // 
            // groupBox4
            // 
            resources.ApplyResources(this.groupBox4, "groupBox4");
            this.groupBox4.Controls.Add(this.checkBox6);
            this.groupBox4.Controls.Add(this.checkBox5);
            this.groupBox4.Controls.Add(this.checkBox4);
            this.groupBox4.Controls.Add(this.checkBox3);
            this.groupBox4.Controls.Add(this.checkBox2);
            this.groupBox4.Controls.Add(this.checkBox1);
            this.helpProvider1.SetHelpKeyword(this.groupBox4, resources.GetString("groupBox4.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.groupBox4, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("groupBox4.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.groupBox4, resources.GetString("groupBox4.HelpString"));
            this.groupBox4.Name = "groupBox4";
            this.helpProvider1.SetShowHelp(this.groupBox4, ((bool)(resources.GetObject("groupBox4.ShowHelp"))));
            this.groupBox4.TabStop = false;
            this.toolTip1.SetToolTip(this.groupBox4, resources.GetString("groupBox4.ToolTip"));
            // 
            // checkBox6
            // 
            resources.ApplyResources(this.checkBox6, "checkBox6");
            this.helpProvider1.SetHelpKeyword(this.checkBox6, resources.GetString("checkBox6.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.checkBox6, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("checkBox6.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.checkBox6, resources.GetString("checkBox6.HelpString"));
            this.checkBox6.Name = "checkBox6";
            this.helpProvider1.SetShowHelp(this.checkBox6, ((bool)(resources.GetObject("checkBox6.ShowHelp"))));
            this.toolTip1.SetToolTip(this.checkBox6, resources.GetString("checkBox6.ToolTip"));
            this.checkBox6.UseVisualStyleBackColor = true;
            // 
            // checkBox5
            // 
            resources.ApplyResources(this.checkBox5, "checkBox5");
            this.helpProvider1.SetHelpKeyword(this.checkBox5, resources.GetString("checkBox5.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.checkBox5, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("checkBox5.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.checkBox5, resources.GetString("checkBox5.HelpString"));
            this.checkBox5.Name = "checkBox5";
            this.helpProvider1.SetShowHelp(this.checkBox5, ((bool)(resources.GetObject("checkBox5.ShowHelp"))));
            this.toolTip1.SetToolTip(this.checkBox5, resources.GetString("checkBox5.ToolTip"));
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            resources.ApplyResources(this.checkBox4, "checkBox4");
            this.helpProvider1.SetHelpKeyword(this.checkBox4, resources.GetString("checkBox4.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.checkBox4, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("checkBox4.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.checkBox4, resources.GetString("checkBox4.HelpString"));
            this.checkBox4.Name = "checkBox4";
            this.helpProvider1.SetShowHelp(this.checkBox4, ((bool)(resources.GetObject("checkBox4.ShowHelp"))));
            this.toolTip1.SetToolTip(this.checkBox4, resources.GetString("checkBox4.ToolTip"));
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            resources.ApplyResources(this.checkBox3, "checkBox3");
            this.helpProvider1.SetHelpKeyword(this.checkBox3, resources.GetString("checkBox3.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.checkBox3, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("checkBox3.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.checkBox3, resources.GetString("checkBox3.HelpString"));
            this.checkBox3.Name = "checkBox3";
            this.helpProvider1.SetShowHelp(this.checkBox3, ((bool)(resources.GetObject("checkBox3.ShowHelp"))));
            this.toolTip1.SetToolTip(this.checkBox3, resources.GetString("checkBox3.ToolTip"));
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            resources.ApplyResources(this.checkBox2, "checkBox2");
            this.helpProvider1.SetHelpKeyword(this.checkBox2, resources.GetString("checkBox2.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.checkBox2, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("checkBox2.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.checkBox2, resources.GetString("checkBox2.HelpString"));
            this.checkBox2.Name = "checkBox2";
            this.helpProvider1.SetShowHelp(this.checkBox2, ((bool)(resources.GetObject("checkBox2.ShowHelp"))));
            this.toolTip1.SetToolTip(this.checkBox2, resources.GetString("checkBox2.ToolTip"));
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            resources.ApplyResources(this.checkBox1, "checkBox1");
            this.helpProvider1.SetHelpKeyword(this.checkBox1, resources.GetString("checkBox1.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.checkBox1, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("checkBox1.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.checkBox1, resources.GetString("checkBox1.HelpString"));
            this.checkBox1.Name = "checkBox1";
            this.helpProvider1.SetShowHelp(this.checkBox1, ((bool)(resources.GetObject("checkBox1.ShowHelp"))));
            this.toolTip1.SetToolTip(this.checkBox1, resources.GetString("checkBox1.ToolTip"));
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            resources.ApplyResources(this.button2, "button2");
            this.helpProvider1.SetHelpKeyword(this.button2, resources.GetString("button2.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.button2, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("button2.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.button2, resources.GetString("button2.HelpString"));
            this.button2.Name = "button2";
            this.helpProvider1.SetShowHelp(this.button2, ((bool)(resources.GetObject("button2.ShowHelp"))));
            this.toolTip1.SetToolTip(this.button2, resources.GetString("button2.ToolTip"));
            this.button2.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            resources.ApplyResources(this.groupBox6, "groupBox6");
            this.groupBox6.Controls.Add(this.radioButton12);
            this.groupBox6.Controls.Add(this.radioButton9);
            this.groupBox6.Controls.Add(this.radioButton10);
            this.groupBox6.Controls.Add(this.radioButton11);
            this.groupBox6.ForeColor = System.Drawing.SystemColors.Highlight;
            this.helpProvider1.SetHelpKeyword(this.groupBox6, resources.GetString("groupBox6.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.groupBox6, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("groupBox6.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.groupBox6, resources.GetString("groupBox6.HelpString"));
            this.groupBox6.Name = "groupBox6";
            this.helpProvider1.SetShowHelp(this.groupBox6, ((bool)(resources.GetObject("groupBox6.ShowHelp"))));
            this.groupBox6.TabStop = false;
            this.toolTip1.SetToolTip(this.groupBox6, resources.GetString("groupBox6.ToolTip"));
            // 
            // groupBox5
            // 
            resources.ApplyResources(this.groupBox5, "groupBox5");
            this.groupBox5.Controls.Add(this.label15);
            this.groupBox5.Controls.Add(this.label14);
            this.groupBox5.Controls.Add(this.SalaryTo);
            this.groupBox5.Controls.Add(this.label10);
            this.groupBox5.Controls.Add(this.SalaryFrom);
            this.groupBox5.Controls.Add(this.label12);
            this.groupBox5.ForeColor = System.Drawing.SystemColors.Highlight;
            this.helpProvider1.SetHelpKeyword(this.groupBox5, resources.GetString("groupBox5.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.groupBox5, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("groupBox5.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.groupBox5, resources.GetString("groupBox5.HelpString"));
            this.groupBox5.Name = "groupBox5";
            this.helpProvider1.SetShowHelp(this.groupBox5, ((bool)(resources.GetObject("groupBox5.ShowHelp"))));
            this.groupBox5.TabStop = false;
            this.toolTip1.SetToolTip(this.groupBox5, resources.GetString("groupBox5.ToolTip"));
            // 
            // label15
            // 
            resources.ApplyResources(this.label15, "label15");
            this.label15.ForeColor = System.Drawing.Color.Green;
            this.helpProvider1.SetHelpKeyword(this.label15, resources.GetString("label15.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.label15, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("label15.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.label15, resources.GetString("label15.HelpString"));
            this.label15.Name = "label15";
            this.helpProvider1.SetShowHelp(this.label15, ((bool)(resources.GetObject("label15.ShowHelp"))));
            this.toolTip1.SetToolTip(this.label15, resources.GetString("label15.ToolTip"));
            // 
            // label14
            // 
            resources.ApplyResources(this.label14, "label14");
            this.label14.ForeColor = System.Drawing.Color.Green;
            this.helpProvider1.SetHelpKeyword(this.label14, resources.GetString("label14.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.label14, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("label14.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.label14, resources.GetString("label14.HelpString"));
            this.label14.Name = "label14";
            this.helpProvider1.SetShowHelp(this.label14, ((bool)(resources.GetObject("label14.ShowHelp"))));
            this.toolTip1.SetToolTip(this.label14, resources.GetString("label14.ToolTip"));
            // 
            // SalaryTo
            // 
            resources.ApplyResources(this.SalaryTo, "SalaryTo");
            this.helpProvider1.SetHelpKeyword(this.SalaryTo, resources.GetString("SalaryTo.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.SalaryTo, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("SalaryTo.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.SalaryTo, resources.GetString("SalaryTo.HelpString"));
            this.SalaryTo.Maximum = new decimal(new int[] {
            1316134912,
            2328,
            0,
            0});
            this.SalaryTo.Name = "SalaryTo";
            this.helpProvider1.SetShowHelp(this.SalaryTo, ((bool)(resources.GetObject("SalaryTo.ShowHelp"))));
            this.toolTip1.SetToolTip(this.SalaryTo, resources.GetString("SalaryTo.ToolTip"));
            // 
            // label10
            // 
            resources.ApplyResources(this.label10, "label10");
            this.label10.ForeColor = System.Drawing.SystemColors.Desktop;
            this.helpProvider1.SetHelpKeyword(this.label10, resources.GetString("label10.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.label10, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("label10.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.label10, resources.GetString("label10.HelpString"));
            this.label10.Name = "label10";
            this.helpProvider1.SetShowHelp(this.label10, ((bool)(resources.GetObject("label10.ShowHelp"))));
            this.toolTip1.SetToolTip(this.label10, resources.GetString("label10.ToolTip"));
            // 
            // SalaryFrom
            // 
            resources.ApplyResources(this.SalaryFrom, "SalaryFrom");
            this.helpProvider1.SetHelpKeyword(this.SalaryFrom, resources.GetString("SalaryFrom.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.SalaryFrom, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("SalaryFrom.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.SalaryFrom, resources.GetString("SalaryFrom.HelpString"));
            this.SalaryFrom.Maximum = new decimal(new int[] {
            1316134912,
            2328,
            0,
            0});
            this.SalaryFrom.Name = "SalaryFrom";
            this.helpProvider1.SetShowHelp(this.SalaryFrom, ((bool)(resources.GetObject("SalaryFrom.ShowHelp"))));
            this.toolTip1.SetToolTip(this.SalaryFrom, resources.GetString("SalaryFrom.ToolTip"));
            // 
            // button1
            // 
            resources.ApplyResources(this.button1, "button1");
            this.helpProvider1.SetHelpKeyword(this.button1, resources.GetString("button1.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.button1, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("button1.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.button1, resources.GetString("button1.HelpString"));
            this.button1.Name = "button1";
            this.helpProvider1.SetShowHelp(this.button1, ((bool)(resources.GetObject("button1.ShowHelp"))));
            this.toolTip1.SetToolTip(this.button1, resources.GetString("button1.ToolTip"));
            this.button1.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            resources.ApplyResources(this.groupBox3, "groupBox3");
            this.groupBox3.Controls.Add(this.radioButton8);
            this.groupBox3.Controls.Add(this.radioButton7);
            this.groupBox3.Controls.Add(this.radioButton4);
            this.groupBox3.Controls.Add(this.radioButton5);
            this.groupBox3.Controls.Add(this.radioButton6);
            this.groupBox3.ForeColor = System.Drawing.SystemColors.Highlight;
            this.helpProvider1.SetHelpKeyword(this.groupBox3, resources.GetString("groupBox3.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.groupBox3, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("groupBox3.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.groupBox3, resources.GetString("groupBox3.HelpString"));
            this.groupBox3.Name = "groupBox3";
            this.helpProvider1.SetShowHelp(this.groupBox3, ((bool)(resources.GetObject("groupBox3.ShowHelp"))));
            this.groupBox3.TabStop = false;
            this.toolTip1.SetToolTip(this.groupBox3, resources.GetString("groupBox3.ToolTip"));
            // 
            // radioButton8
            // 
            resources.ApplyResources(this.radioButton8, "radioButton8");
            this.radioButton8.ForeColor = System.Drawing.SystemColors.Desktop;
            this.helpProvider1.SetHelpKeyword(this.radioButton8, resources.GetString("radioButton8.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.radioButton8, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("radioButton8.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.radioButton8, resources.GetString("radioButton8.HelpString"));
            this.radioButton8.Name = "radioButton8";
            this.helpProvider1.SetShowHelp(this.radioButton8, ((bool)(resources.GetObject("radioButton8.ShowHelp"))));
            this.radioButton8.TabStop = true;
            this.toolTip1.SetToolTip(this.radioButton8, resources.GetString("radioButton8.ToolTip"));
            this.radioButton8.UseVisualStyleBackColor = true;
            // 
            // radioButton7
            // 
            resources.ApplyResources(this.radioButton7, "radioButton7");
            this.radioButton7.ForeColor = System.Drawing.SystemColors.Desktop;
            this.helpProvider1.SetHelpKeyword(this.radioButton7, resources.GetString("radioButton7.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.radioButton7, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("radioButton7.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.radioButton7, resources.GetString("radioButton7.HelpString"));
            this.radioButton7.Name = "radioButton7";
            this.helpProvider1.SetShowHelp(this.radioButton7, ((bool)(resources.GetObject("radioButton7.ShowHelp"))));
            this.radioButton7.TabStop = true;
            this.toolTip1.SetToolTip(this.radioButton7, resources.GetString("radioButton7.ToolTip"));
            this.radioButton7.UseVisualStyleBackColor = true;
            // 
            // radioButton4
            // 
            resources.ApplyResources(this.radioButton4, "radioButton4");
            this.radioButton4.ForeColor = System.Drawing.SystemColors.Desktop;
            this.helpProvider1.SetHelpKeyword(this.radioButton4, resources.GetString("radioButton4.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.radioButton4, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("radioButton4.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.radioButton4, resources.GetString("radioButton4.HelpString"));
            this.radioButton4.Name = "radioButton4";
            this.helpProvider1.SetShowHelp(this.radioButton4, ((bool)(resources.GetObject("radioButton4.ShowHelp"))));
            this.radioButton4.TabStop = true;
            this.toolTip1.SetToolTip(this.radioButton4, resources.GetString("radioButton4.ToolTip"));
            this.radioButton4.UseVisualStyleBackColor = true;
            // 
            // radioButton5
            // 
            resources.ApplyResources(this.radioButton5, "radioButton5");
            this.radioButton5.ForeColor = System.Drawing.SystemColors.Desktop;
            this.helpProvider1.SetHelpKeyword(this.radioButton5, resources.GetString("radioButton5.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.radioButton5, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("radioButton5.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.radioButton5, resources.GetString("radioButton5.HelpString"));
            this.radioButton5.Name = "radioButton5";
            this.helpProvider1.SetShowHelp(this.radioButton5, ((bool)(resources.GetObject("radioButton5.ShowHelp"))));
            this.radioButton5.TabStop = true;
            this.toolTip1.SetToolTip(this.radioButton5, resources.GetString("radioButton5.ToolTip"));
            this.radioButton5.UseVisualStyleBackColor = true;
            // 
            // radioButton6
            // 
            resources.ApplyResources(this.radioButton6, "radioButton6");
            this.radioButton6.ForeColor = System.Drawing.SystemColors.Desktop;
            this.helpProvider1.SetHelpKeyword(this.radioButton6, resources.GetString("radioButton6.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.radioButton6, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("radioButton6.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.radioButton6, resources.GetString("radioButton6.HelpString"));
            this.radioButton6.Name = "radioButton6";
            this.helpProvider1.SetShowHelp(this.radioButton6, ((bool)(resources.GetObject("radioButton6.ShowHelp"))));
            this.radioButton6.TabStop = true;
            this.toolTip1.SetToolTip(this.radioButton6, resources.GetString("radioButton6.ToolTip"));
            this.radioButton6.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            resources.ApplyResources(this.button3, "button3");
            this.helpProvider1.SetHelpKeyword(this.button3, resources.GetString("button3.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.button3, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("button3.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.button3, resources.GetString("button3.HelpString"));
            this.button3.Name = "button3";
            this.helpProvider1.SetShowHelp(this.button3, ((bool)(resources.GetObject("button3.ShowHelp"))));
            this.toolTip1.SetToolTip(this.button3, resources.GetString("button3.ToolTip"));
            this.button3.UseVisualStyleBackColor = true;
            // 
            // Name
            // 
            resources.ApplyResources(this.Name, "Name");
            this.helpProvider1.SetHelpKeyword(this.Name, resources.GetString("Name.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.Name, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("Name.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.Name, resources.GetString("Name.HelpString"));
            this.Name.Name = "Name";
            this.helpProvider1.SetShowHelp(this.Name, ((bool)(resources.GetObject("Name.ShowHelp"))));
            this.toolTip1.SetToolTip(this.Name, resources.GetString("Name.ToolTip"));
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.ForeColor = System.Drawing.SystemColors.Highlight;
            this.helpProvider1.SetHelpKeyword(this.label3, resources.GetString("label3.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.label3, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("label3.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.label3, resources.GetString("label3.HelpString"));
            this.label3.Name = "label3";
            this.helpProvider1.SetShowHelp(this.label3, ((bool)(resources.GetObject("label3.ShowHelp"))));
            this.toolTip1.SetToolTip(this.label3, resources.GetString("label3.ToolTip"));
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.ForeColor = System.Drawing.SystemColors.Highlight;
            this.helpProvider1.SetHelpKeyword(this.label2, resources.GetString("label2.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.label2, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("label2.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.label2, resources.GetString("label2.HelpString"));
            this.label2.Name = "label2";
            this.helpProvider1.SetShowHelp(this.label2, ((bool)(resources.GetObject("label2.ShowHelp"))));
            this.toolTip1.SetToolTip(this.label2, resources.GetString("label2.ToolTip"));
            // 
            // Patronymic
            // 
            resources.ApplyResources(this.Patronymic, "Patronymic");
            this.helpProvider1.SetHelpKeyword(this.Patronymic, resources.GetString("Patronymic.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.Patronymic, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("Patronymic.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.Patronymic, resources.GetString("Patronymic.HelpString"));
            this.Patronymic.Name = "Patronymic";
            this.helpProvider1.SetShowHelp(this.Patronymic, ((bool)(resources.GetObject("Patronymic.ShowHelp"))));
            this.toolTip1.SetToolTip(this.Patronymic, resources.GetString("Patronymic.ToolTip"));
            // 
            // groupBox1
            // 
            resources.ApplyResources(this.groupBox1, "groupBox1");
            this.groupBox1.Controls.Add(this.radioButton3);
            this.groupBox1.Controls.Add(this.radioButton2);
            this.groupBox1.Controls.Add(this.radioButton1);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.Highlight;
            this.helpProvider1.SetHelpKeyword(this.groupBox1, resources.GetString("groupBox1.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.groupBox1, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("groupBox1.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.groupBox1, resources.GetString("groupBox1.HelpString"));
            this.groupBox1.Name = "groupBox1";
            this.helpProvider1.SetShowHelp(this.groupBox1, ((bool)(resources.GetObject("groupBox1.ShowHelp"))));
            this.groupBox1.TabStop = false;
            this.toolTip1.SetToolTip(this.groupBox1, resources.GetString("groupBox1.ToolTip"));
            // 
            // Sourname
            // 
            resources.ApplyResources(this.Sourname, "Sourname");
            this.helpProvider1.SetHelpKeyword(this.Sourname, resources.GetString("Sourname.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.Sourname, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("Sourname.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.Sourname, resources.GetString("Sourname.HelpString"));
            this.Sourname.Name = "Sourname";
            this.helpProvider1.SetShowHelp(this.Sourname, ((bool)(resources.GetObject("Sourname.ShowHelp"))));
            this.toolTip1.SetToolTip(this.Sourname, resources.GetString("Sourname.ToolTip"));
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.ForeColor = System.Drawing.SystemColors.Highlight;
            this.helpProvider1.SetHelpKeyword(this.label1, resources.GetString("label1.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.label1, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("label1.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.label1, resources.GetString("label1.HelpString"));
            this.label1.Name = "label1";
            this.helpProvider1.SetShowHelp(this.label1, ((bool)(resources.GetObject("label1.ShowHelp"))));
            this.toolTip1.SetToolTip(this.label1, resources.GetString("label1.ToolTip"));
            // 
            // label8
            // 
            resources.ApplyResources(this.label8, "label8");
            this.label8.ForeColor = System.Drawing.SystemColors.Desktop;
            this.helpProvider1.SetHelpKeyword(this.label8, resources.GetString("label8.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.label8, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("label8.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.label8, resources.GetString("label8.HelpString"));
            this.label8.Name = "label8";
            this.helpProvider1.SetShowHelp(this.label8, ((bool)(resources.GetObject("label8.ShowHelp"))));
            this.toolTip1.SetToolTip(this.label8, resources.GetString("label8.ToolTip"));
            // 
            // Place
            // 
            resources.ApplyResources(this.Place, "Place");
            this.Place.FormattingEnabled = true;
            this.helpProvider1.SetHelpKeyword(this.Place, resources.GetString("Place.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.Place, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("Place.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.Place, resources.GetString("Place.HelpString"));
            this.Place.Items.AddRange(new object[] {
            resources.GetString("Place.Items"),
            resources.GetString("Place.Items1"),
            resources.GetString("Place.Items2"),
            resources.GetString("Place.Items3"),
            resources.GetString("Place.Items4"),
            resources.GetString("Place.Items5"),
            resources.GetString("Place.Items6"),
            resources.GetString("Place.Items7"),
            resources.GetString("Place.Items8"),
            resources.GetString("Place.Items9"),
            resources.GetString("Place.Items10"),
            resources.GetString("Place.Items11"),
            resources.GetString("Place.Items12"),
            resources.GetString("Place.Items13"),
            resources.GetString("Place.Items14"),
            resources.GetString("Place.Items15"),
            resources.GetString("Place.Items16"),
            resources.GetString("Place.Items17"),
            resources.GetString("Place.Items18"),
            resources.GetString("Place.Items19"),
            resources.GetString("Place.Items20"),
            resources.GetString("Place.Items21"),
            resources.GetString("Place.Items22"),
            resources.GetString("Place.Items23"),
            resources.GetString("Place.Items24"),
            resources.GetString("Place.Items25"),
            resources.GetString("Place.Items26"),
            resources.GetString("Place.Items27"),
            resources.GetString("Place.Items28"),
            resources.GetString("Place.Items29"),
            resources.GetString("Place.Items30"),
            resources.GetString("Place.Items31"),
            resources.GetString("Place.Items32"),
            resources.GetString("Place.Items33"),
            resources.GetString("Place.Items34"),
            resources.GetString("Place.Items35"),
            resources.GetString("Place.Items36"),
            resources.GetString("Place.Items37"),
            resources.GetString("Place.Items38"),
            resources.GetString("Place.Items39"),
            resources.GetString("Place.Items40"),
            resources.GetString("Place.Items41"),
            resources.GetString("Place.Items42"),
            resources.GetString("Place.Items43"),
            resources.GetString("Place.Items44"),
            resources.GetString("Place.Items45"),
            resources.GetString("Place.Items46"),
            resources.GetString("Place.Items47"),
            resources.GetString("Place.Items48"),
            resources.GetString("Place.Items49"),
            resources.GetString("Place.Items50"),
            resources.GetString("Place.Items51"),
            resources.GetString("Place.Items52"),
            resources.GetString("Place.Items53"),
            resources.GetString("Place.Items54"),
            resources.GetString("Place.Items55"),
            resources.GetString("Place.Items56"),
            resources.GetString("Place.Items57"),
            resources.GetString("Place.Items58"),
            resources.GetString("Place.Items59"),
            resources.GetString("Place.Items60"),
            resources.GetString("Place.Items61"),
            resources.GetString("Place.Items62"),
            resources.GetString("Place.Items63"),
            resources.GetString("Place.Items64"),
            resources.GetString("Place.Items65"),
            resources.GetString("Place.Items66"),
            resources.GetString("Place.Items67"),
            resources.GetString("Place.Items68"),
            resources.GetString("Place.Items69"),
            resources.GetString("Place.Items70"),
            resources.GetString("Place.Items71"),
            resources.GetString("Place.Items72"),
            resources.GetString("Place.Items73"),
            resources.GetString("Place.Items74"),
            resources.GetString("Place.Items75"),
            resources.GetString("Place.Items76"),
            resources.GetString("Place.Items77"),
            resources.GetString("Place.Items78"),
            resources.GetString("Place.Items79"),
            resources.GetString("Place.Items80"),
            resources.GetString("Place.Items81"),
            resources.GetString("Place.Items82"),
            resources.GetString("Place.Items83"),
            resources.GetString("Place.Items84"),
            resources.GetString("Place.Items85"),
            resources.GetString("Place.Items86"),
            resources.GetString("Place.Items87"),
            resources.GetString("Place.Items88"),
            resources.GetString("Place.Items89"),
            resources.GetString("Place.Items90"),
            resources.GetString("Place.Items91"),
            resources.GetString("Place.Items92"),
            resources.GetString("Place.Items93"),
            resources.GetString("Place.Items94"),
            resources.GetString("Place.Items95"),
            resources.GetString("Place.Items96"),
            resources.GetString("Place.Items97"),
            resources.GetString("Place.Items98"),
            resources.GetString("Place.Items99"),
            resources.GetString("Place.Items100"),
            resources.GetString("Place.Items101"),
            resources.GetString("Place.Items102"),
            resources.GetString("Place.Items103"),
            resources.GetString("Place.Items104"),
            resources.GetString("Place.Items105"),
            resources.GetString("Place.Items106"),
            resources.GetString("Place.Items107"),
            resources.GetString("Place.Items108"),
            resources.GetString("Place.Items109"),
            resources.GetString("Place.Items110"),
            resources.GetString("Place.Items111"),
            resources.GetString("Place.Items112")});
            this.Place.Name = "Place";
            this.helpProvider1.SetShowHelp(this.Place, ((bool)(resources.GetObject("Place.ShowHelp"))));
            this.toolTip1.SetToolTip(this.Place, resources.GetString("Place.ToolTip"));
            // 
            // label7
            // 
            resources.ApplyResources(this.label7, "label7");
            this.label7.ForeColor = System.Drawing.SystemColors.Desktop;
            this.helpProvider1.SetHelpKeyword(this.label7, resources.GetString("label7.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.label7, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("label7.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.label7, resources.GetString("label7.HelpString"));
            this.label7.Name = "label7";
            this.helpProvider1.SetShowHelp(this.label7, ((bool)(resources.GetObject("label7.ShowHelp"))));
            this.toolTip1.SetToolTip(this.label7, resources.GetString("label7.ToolTip"));
            // 
            // Phone
            // 
            resources.ApplyResources(this.Phone, "Phone");
            this.helpProvider1.SetHelpKeyword(this.Phone, resources.GetString("Phone.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.Phone, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("Phone.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.Phone, resources.GetString("Phone.HelpString"));
            this.Phone.Name = "Phone";
            this.helpProvider1.SetShowHelp(this.Phone, ((bool)(resources.GetObject("Phone.ShowHelp"))));
            this.toolTip1.SetToolTip(this.Phone, resources.GetString("Phone.ToolTip"));
            // 
            // Mobile
            // 
            resources.ApplyResources(this.Mobile, "Mobile");
            this.Mobile.FormattingEnabled = true;
            this.helpProvider1.SetHelpKeyword(this.Mobile, resources.GetString("Mobile.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.Mobile, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("Mobile.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.Mobile, resources.GetString("Mobile.HelpString"));
            this.Mobile.Items.AddRange(new object[] {
            resources.GetString("Mobile.Items"),
            resources.GetString("Mobile.Items1"),
            resources.GetString("Mobile.Items2"),
            resources.GetString("Mobile.Items3")});
            this.Mobile.Name = "Mobile";
            this.helpProvider1.SetShowHelp(this.Mobile, ((bool)(resources.GetObject("Mobile.ShowHelp"))));
            this.toolTip1.SetToolTip(this.Mobile, resources.GetString("Mobile.ToolTip"));
            // 
            // label9
            // 
            resources.ApplyResources(this.label9, "label9");
            this.label9.ForeColor = System.Drawing.SystemColors.Desktop;
            this.helpProvider1.SetHelpKeyword(this.label9, resources.GetString("label9.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.label9, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("label9.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.label9, resources.GetString("label9.HelpString"));
            this.label9.Name = "label9";
            this.helpProvider1.SetShowHelp(this.label9, ((bool)(resources.GetObject("label9.ShowHelp"))));
            this.toolTip1.SetToolTip(this.label9, resources.GetString("label9.ToolTip"));
            // 
            // groupBox2
            // 
            resources.ApplyResources(this.groupBox2, "groupBox2");
            this.groupBox2.Controls.Add(this.YearDropBox);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.Month);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.Day);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.Highlight;
            this.helpProvider1.SetHelpKeyword(this.groupBox2, resources.GetString("groupBox2.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.groupBox2, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("groupBox2.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.groupBox2, resources.GetString("groupBox2.HelpString"));
            this.groupBox2.Name = "groupBox2";
            this.helpProvider1.SetShowHelp(this.groupBox2, ((bool)(resources.GetObject("groupBox2.ShowHelp"))));
            this.groupBox2.TabStop = false;
            this.toolTip1.SetToolTip(this.groupBox2, resources.GetString("groupBox2.ToolTip"));
            // 
            // Email
            // 
            resources.ApplyResources(this.Email, "Email");
            this.helpProvider1.SetHelpKeyword(this.Email, resources.GetString("Email.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.Email, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("Email.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.Email, resources.GetString("Email.HelpString"));
            this.Email.Name = "Email";
            this.helpProvider1.SetShowHelp(this.Email, ((bool)(resources.GetObject("Email.ShowHelp"))));
            this.toolTip1.SetToolTip(this.Email, resources.GetString("Email.ToolTip"));
            // 
            // helpProvider1
            // 
            resources.ApplyResources(this.helpProvider1, "helpProvider1");
            // 
            // button7
            // 
            resources.ApplyResources(this.button7, "button7");
            this.button7.Cursor = System.Windows.Forms.Cursors.Help;
            this.helpProvider1.SetHelpKeyword(this.button7, resources.GetString("button7.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.button7, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("button7.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.button7, resources.GetString("button7.HelpString"));
            this.button7.Name = "button7";
            this.helpProvider1.SetShowHelp(this.button7, ((bool)(resources.GetObject("button7.ShowHelp"))));
            this.toolTip1.SetToolTip(this.button7, resources.GetString("button7.ToolTip"));
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // pictureBox2
            // 
            resources.ApplyResources(this.pictureBox2, "pictureBox2");
            this.helpProvider1.SetHelpKeyword(this.pictureBox2, resources.GetString("pictureBox2.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.pictureBox2, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("pictureBox2.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.pictureBox2, resources.GetString("pictureBox2.HelpString"));
            this.pictureBox2.Name = "pictureBox2";
            this.helpProvider1.SetShowHelp(this.pictureBox2, ((bool)(resources.GetObject("pictureBox2.ShowHelp"))));
            this.pictureBox2.TabStop = false;
            this.toolTip1.SetToolTip(this.pictureBox2, resources.GetString("pictureBox2.ToolTip"));
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // pictureBox1
            // 
            resources.ApplyResources(this.pictureBox1, "pictureBox1");
            this.helpProvider1.SetHelpKeyword(this.pictureBox1, resources.GetString("pictureBox1.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this.pictureBox1, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("pictureBox1.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this.pictureBox1, resources.GetString("pictureBox1.HelpString"));
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.TabStop = false;
            this.toolTip1.SetToolTip(this.pictureBox1, resources.GetString("pictureBox1.ToolTip"));
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // Form1
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.HR_Resume);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.Name);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Patronymic);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.Sourname);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.Place);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.Phone);
            this.Controls.Add(this.Mobile);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.Email);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.HelpButton = true;
            this.helpProvider1.SetHelpKeyword(this, resources.GetString("$this.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("$this.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this, resources.GetString("$this.HelpString"));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.helpProvider1.SetShowHelp(this, ((bool)(resources.GetObject("$this.ShowHelp"))));
            this.toolTip1.SetToolTip(this, resources.GetString("$this.ToolTip"));
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SalaryTo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SalaryFrom)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.RadioButton radioButton9;
        private System.Windows.Forms.RadioButton radioButton10;
        private System.Windows.Forms.RadioButton radioButton11;
        private System.Windows.Forms.TextBox HR_Resume;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton12;
        private System.Windows.Forms.ComboBox YearDropBox;
        private System.Windows.Forms.ComboBox Month;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox Day;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.NumericUpDown SalaryTo;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.NumericUpDown SalaryFrom;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RadioButton radioButton8;
        private System.Windows.Forms.RadioButton radioButton7;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.RadioButton radioButton6;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox Name;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox Patronymic;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox Sourname;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox Place;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox Phone;
        private System.Windows.Forms.ComboBox Mobile;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox Email;
        private System.Windows.Forms.HelpProvider helpProvider1;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}

